## **MedTracker — Technical Specification**

Version 0.2 — Draft (updated after prototype design pass)

---

### **1\. General Description**

MedTracker is an Android application for scheduling and tracking medication intake. The key difference from existing solutions (MyTherapy, Medisafe, Pillo): separate drug and schedule models, support for dosing in both units (tablets) and active substance strength (mg), support for tapering/titration—multiple periods with different doses for a single drug—and tracking of medication supply on hand (stock batches), used to suggest which physical tablets/capsules to combine for a given strength dose.

**Platform:** Android  
 **Monetization:** free (monetization TBD)  
 **Localization:** English, Ukrainian  
 **Data Storage:** local (Room/SQLite) \+ backup via Google Drive API

---

### **2\. Target Audience**

People taking medication on complex schedules: gradual dose increase/decrease, multiple intakes per day with different doses, long-term courses with periods, and people who hold multiple strengths of the same drug at once (e.g. leftover boxes from previous prescriptions).

---

### **3\. Data Model**

See document "MedTracker — Data Model". Brief structure:

* **Drug** — drug description (name, form). Unit strength is **no longer stored on the drug itself** — see DrugStockBatch below.
* **DrugStockBatch** — a batch of supply on hand for a drug: quantity \+ strength per unit (number \+ unit: mg, mcg, IU). A single drug can have several batches at once with different strengths (e.g. 30 tablets @ 6 mg and 10 tablets @ 5 mg left over from a previous prescription). The most recently added batch is used as the drug's "reference strength" wherever a single value is needed (e.g. converting a units-based dose for display).
* **ScheduledIntake** — a period for a drug (start date, end date, cycle) containing one or more **IntakeTime** entries.
* **IntakeTime** — a single time-of-day within a ScheduledIntake, each with **its own independent dose** (value \+ mode: units or strength). This replaces the old model where one dose applied to every time in a period — e.g. a period with 08:00 and 20:00 can now have different doses per time.
* **IntakeLog** — actual intake (status, time, source: reminder / manual)

---

### **4\. Functional Requirements**

#### **4.1 Drug Management**

* Create a drug with fields:  
  * Name (text)  
  * Form (tablet, capsule, drops, ml, other — with custom option)  
* Edit and delete drug  
* On drug deletion — warning if there are active periods or stock batches; confirming deletes the drug together with all its periods, stock batches, and history (cascade delete, no archive)

#### **4.2 Supply / Stock Management**

* For each drug — any number of stock batches (DrugStockBatch), entered from the drug detail screen  
* Each batch:  
  * Quantity on hand  
  * Strength per unit (number \+ unit: mg, mcg, IU)  
* Add, edit, delete batches independently of periods  
* Batches are the source of truth for strength — a drug with no batches has no known strength and can only be dosed in units

#### **4.3 Schedule Management**

* For each drug — any number of periods (ScheduledIntake)  
* Each period:  
  * **Start date**, chosen one of two ways:  
    * Custom date (date picker), or  
    * "Continue previous period" — auto-computed as the day after the most recent prior period's end date, when such a period with a defined end exists  
  * **End**, chosen one of three ways:  
    * Specific end date  
    * Duration in days (end date is computed and shown live as start \+ N days)  
    * No end date (ongoing)  
  * One or more times of day (IntakeTime), **each with its own dose** — in units OR in strength (mutual conversion via the drug's batch strengths)  
  * Cycle: daily / every other day / specific days of week / custom  
* Periods of one drug can overlap (different doses morning and evening)  
* Visual list of periods for the drug showing date ranges, per-time doses, and cycle  
* Editing a period only recalculates future/undetermined intakes derived from it; history entries that already carry an explicit status (taken/skipped, whether from a reminder action or a manual entry) are left untouched

#### **4.4 Dose-to-Supply Conversion**

* When a dose is entered in strength (e.g. mg) rather than units, the app searches the drug's stock batches for a combination of whole/half units across one or more batches that sums exactly to the target dose (e.g. target 20 mg with batches of 10 mg, 4 mg, and 16 mg on hand suggests "2 × 10 mg" or "1 × 16 mg + 1 × 4 mg"; target 2 mg from a 4 mg batch suggests "½ × 4 mg")  
* Up to two suggested combinations are shown, preferring fewer total pieces  
* If no exact combination exists from current supply, falls back to a plain mg→units conversion using the reference batch strength, with a note that no exact match was found

#### **4.5 Notifications**

* Push notification at scheduled intake time  
* Actions from notification: "Took it", "Skipped", "Remind later" (snooze)  
* Snooze time setting (default 15 minutes, configurable)  
* Notifications recalculate on schedule changes

#### **4.6 Intake History (IntakeLog)**

* Automatic record creation on notification action  
* Manual entry (retroactive):  
  * Select drug and scheduled intake from schedule  
  * Select actual time (date/time picker)  
  * Actual dose (may differ from scheduled)  
  * Status: took / skipped  
  * Source recorded as manual  
* View history: list by days, filter by drug  
* Edit and delete history entries

#### **4.7 Home Screen**

* List of intakes for today with time, drug, and dose  
* Status of each intake: upcoming / taken / skipped / overdue  
* Quick "Took it" action directly from list (without opening details)  
* Switch to different day (swipe or date picker)

#### **4.8 Backup and Restore (Google Drive API)**

* Authorization via Google account (OAuth2)  
* Export database to JSON file in app hidden folder on Google Drive (appDataFolder)  
* Import/restore from Google Drive file  
* Manual backup trigger by user  
* Optional in future: automatic scheduled backup

---

### **5\. Non-Functional Requirements**

* **Minimum Android version:** API 26 (Android 8.0) — for Notification Channels support  
* **Architecture:** MVVM \+ Repository pattern  
* **Database:** Room (SQLite)  
* **UI:** Jetpack Compose  
* **Notifications:** WorkManager \+ AlarmManager  
* **Language:** Kotlin  
* **Offline-first:** app fully works offline; Google Drive only for backup

---

### **6\. Out of Scope (v1.0)**

* Unscheduled intakes (IntakeLog without ScheduledIntake link)  
* Family/multi-user mode  
* Real-time automatic synchronization  
* History export to PDF/CSV  
* Integration with doctor or pharmacy  
* iOS version  
* Home screen widget (consider for v1.1)  
* Automatic stock depletion (decrementing batch quantity as doses are logged — currently batches are informational only, not consumed)

---

### **7\. Open Questions**

* Do we need statistics/analytics (% of doses taken per period)?  
* Do we need PIN/biometric login?

Resolved during this design pass:

* ~~What happens to IntakeLog when editing ScheduledIntake retroactively?~~ → Recalculates only future/undetermined entries; entries with an explicit status are preserved (see 4.3).  
* ~~On drug deletion: delete related schedules/stock/history or archive?~~ → Cascade delete, no archive (see 4.1).  
* ~~Should logging a dose decrement stock batch quantity automatically?~~ → No for v1; stock is informational only (see Out of Scope, 6).
